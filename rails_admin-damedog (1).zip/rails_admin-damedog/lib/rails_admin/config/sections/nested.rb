require 'rails_admin/config/sections/edit'

module RailsAdmin
  module Config
    module Sections
      class Nested < RailsAdmin::Config::Sections::Edit
      end
    end
  end
end
