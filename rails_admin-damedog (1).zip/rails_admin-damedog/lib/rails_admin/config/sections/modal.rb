require 'rails_admin/config/sections/edit'

module RailsAdmin
  module Config
    module Sections
      class Modal < RailsAdmin::Config::Sections::Edit
      end
    end
  end
end
