require 'rails_admin/config/sections/base'

module RailsAdmin
  module Config
    module Sections
      class Show < RailsAdmin::Config::Sections::Base
      end
    end
  end
end
