Hamlit::Template.options[:ugly] = true
