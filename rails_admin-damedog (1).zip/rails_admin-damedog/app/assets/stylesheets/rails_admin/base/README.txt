For RailsAdmin developers:
We should use sass variables & mixins as much as possible so that themers/users can override them cleanly
