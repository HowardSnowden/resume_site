class Hardball < Ball
end
