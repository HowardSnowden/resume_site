class User
  class Confirmed < User
  end
end
