PaperTrail.config.track_associations = false if defined?(PaperTrail)
